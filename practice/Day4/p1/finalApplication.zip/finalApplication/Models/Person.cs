using System;
using System.Collections.Generic;

namespace Models;

public class Person
{
    public string Name;
    public int Age;
    public int Id;
}
